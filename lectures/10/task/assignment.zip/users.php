<?php

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>10. cvičení</title>
    </head>
    <body>
        <h1>Zaregistrovaní uživatelé</h1>

        <ul>
        </ul>

    </body>
</html>
