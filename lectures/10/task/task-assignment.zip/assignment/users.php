<?php

/*
Tasks:
    - Add list of registered users
*/

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Task solution</title>
    </head>
    <body>
        <h1>Registered users</h1>

        <ul>
        </ul>
    </body>
</html>
