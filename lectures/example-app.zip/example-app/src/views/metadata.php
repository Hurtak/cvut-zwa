<meta charset="utf-8">
<link rel="stylesheet" href="<?php echo STATIC_DIR ?>/styles.css">
