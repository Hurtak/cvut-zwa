<h3>Debug Form data</h3>
<pre><?php var_dump($_POST); ?></pre>

<h3>Debug DB data</h3>
<pre><?php var_dump($db->getDebugData()); ?></pre>
